#include <stdio.h>

void Func1(){
	int age;
	char name[100],prof[100],address[100],semesters[100];
	//Enter age
	printf("Please enter your age: ");
	scanf("%d",&age);
	getchar();//clear ipn buffer

	//Enter name
	printf("Please enter your name: ");
	fgets(name, sizeof(name), stdin);
	//Enter prof
	printf("Please enter your professional: ");
	scanf("%s",prof);
	
	//Enter address
	printf("Please enter your address: ");
	scanf("%s",address);
    //Enter semester
	printf("Please enter your semester: ");
	scanf("%s",semesters);
	//Print all info to scr
	printf("Your age is: %d\n",age);
	printf("Your name is: %s",name);
	printf("Your prof is : %s\n",prof);
	printf("Your address is : %s\n",address);
	printf("Your semesters is : %s\n",semesters);
}
