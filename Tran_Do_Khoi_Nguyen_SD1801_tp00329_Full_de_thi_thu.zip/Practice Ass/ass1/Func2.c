#include <stdio.h>

void Func2(){
	int n,tong=0,i;
	printf("Please enter n number: ");
	scanf("%d",&n);
	for (i = 1;i<=n;i++){
		tong+=i;
	}
	printf("Tong cua day tu 1 --> %d = %d\n\n",n,tong);
}
