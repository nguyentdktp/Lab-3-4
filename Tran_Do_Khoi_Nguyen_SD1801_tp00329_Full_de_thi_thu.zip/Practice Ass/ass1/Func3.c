#include <stdio.h>

struct Stu_Info{
	char stu_class[10];
	int size_class;
}arr_sv[100];
void Func3(){
	int i,class_sum;
	printf("Please enter sum of the class u want to enter: ");
	scanf("%d",&class_sum);
	
	for (i = 0;i<class_sum;i++){
		getchar();
		printf("Please enter the class: ");
		fgets(arr_sv[i].stu_class,sizeof(arr_sv[i].stu_class),stdin);
		printf("Please enter an amount of student: ");
		scanf("%d",&arr_sv[i].size_class);
		getchar();
	}
	for (i = 0;i<class_sum;i++){
		printf("+++++++++++++++++++++++++++++++\n");
		printf("Class: %s\n",arr_sv[i].stu_class);
		printf("Amount of Student: %d\n",arr_sv[i].size_class);
		printf("+++++++++++++++++++++++++++++++\n\n\n\n");
	}
	for (i = 0;i<class_sum;i++){
		if (arr_sv[i].size_class<30){
			printf("\nThe class with the stu less than 30 is: %s",arr_sv[i].stu_class);
		}
	}
}
