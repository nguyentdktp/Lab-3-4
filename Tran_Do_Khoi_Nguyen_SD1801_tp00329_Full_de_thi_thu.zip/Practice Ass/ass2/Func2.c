#include <stdio.h>

void Func2(){
	int n,tong=0,i;
	printf("Please enter n number: ");
	scanf("%d",&n);
	for (i = 1;i<=n;i++){
		tong+=i;
	}
	printf("Sum of an array from 1 --> %d = %d\n\n",n,tong);
	if (n%2==0){
		printf("%d is a weird number\n\n",n);
	}
	else{
		printf("%d is not a weird number\n\n",n);
	}
}
