#include <stdio.h>

struct TV_Info{
	char model[100];
	int size_tv;
}arr_tv[100];

void Func3(){
	int i,tv_sum;
	float tong = 0,tbc;
	printf("Please enter sum of the TV u want to enter: ");
	scanf("%d",&tv_sum);
	
	for (i = 0;i<tv_sum;i++){
		getchar();
		printf("Please enter the model: ");
		fgets(arr_tv[i].model,sizeof(arr_tv[i].model),stdin);
		printf("Please the inch of the TV: ");
		scanf("%d",&arr_tv[i].size_tv);
		getchar();
	}
	for (i = 0;i<tv_sum;i++){
		printf("+++++++++++++++++++++++++++++++\n");
		printf("Model TV: %s\n",arr_tv[i].model);
		printf("Size of TV: %d\n",arr_tv[i].size_tv);
		printf("+++++++++++++++++++++++++++++++\n\n\n\n");
	}
	for (i = 0;i<tv_sum;i++){
		tong+=arr_tv[i].size_tv;
	}
	tbc = tong/tv_sum;
	printf("Avergae inch of TV is: %.1f\n\n",tbc);
	int max_inch = arr_tv[0].size_tv;
	for (i = 0;i<tv_sum;i++){
		if (arr_tv[i].size_tv>max_inch){
			max_inch = arr_tv[i].size_tv;
		}
	}
	printf("The biggest TV in list is: %d\n\n",max_inch);
}
