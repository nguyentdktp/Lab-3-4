#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include "functions.h"

int main(){
	int menu_inp;
	char decision;
	MENU:
		do{
		printf("++++++++++++++++++++++++++++++++++++++\n"
	           "+ [1]: Enter personal information    +\n"
	           "+ [2]: Caculate an array from 1 to n +\n"
	           "+ [3]: Television's info             +\n"
	           "+ [0]: Exit program                  +\n");
	    printf("Please choose the prog u want: ");
	    scanf("%d",&menu_inp);
	    switch(menu_inp){
	    	case 1:
	    		system("CLS");
	    		Func1();
	    		break;
	    	case 2:
	    		system("CLS");
	    		Func2();
	    		break;
	    	case 3:
	    		system("CLS");
	    		Func3();
			    break;
			case 0:
				printf("Do u want to exit?(Y/N): ");
				scanf("%s",&decision);
				if (toupper(decision)=='Y'){
					printf("Exiting...");
					abort();
				}
				else if(toupper(decision)=='N'){
					goto MENU;
				}
				break;
			default:
			    printf("\nPls just only type the number of the programes! ");		
		}
	}while (menu_inp>0&&menu_inp<4);
}
